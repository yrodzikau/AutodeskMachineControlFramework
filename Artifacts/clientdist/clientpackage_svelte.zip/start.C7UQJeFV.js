import{l as o,a as r}from"../chunks/EvBA84Ey.js";export{o as load_css,r as start};
