import{l as o,a as r}from"../chunks/BiP8i9SV.js";export{o as load_css,r as start};
