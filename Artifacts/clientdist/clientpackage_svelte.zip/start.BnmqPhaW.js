import{l as o,a as r}from"../chunks/D5PCCOQo.js";export{o as load_css,r as start};
