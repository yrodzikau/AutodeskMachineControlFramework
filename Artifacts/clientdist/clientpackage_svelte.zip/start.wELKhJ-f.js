import{l as o,a as r}from"../chunks/Db24AFJr.js";export{o as load_css,r as start};
