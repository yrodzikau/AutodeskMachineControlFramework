import{l as o,a as r}from"../chunks/D-i8uJ4C.js";export{o as load_css,r as start};
