import{l as o,a as r}from"../chunks/e5LTO9lr.js";export{o as load_css,r as start};
