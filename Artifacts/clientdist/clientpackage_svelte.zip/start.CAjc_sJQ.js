import{l as o,a as r}from"../chunks/Dx4bYZyO.js";export{o as load_css,r as start};
