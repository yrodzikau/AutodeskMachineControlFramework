import{l as o,a as r}from"../chunks/COJ37jwe.js";export{o as load_css,r as start};
